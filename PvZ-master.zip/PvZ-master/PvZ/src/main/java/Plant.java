/**
 * All Plants implemented in our implementation of PvZ.
 * 
 * @author kylehorne
 * @version 25 Nov 18
 */
public enum Plant {
	
	PEA_SHOOTER,
	
	SUNFLOWER,
	
	WALNUT,
	
	REPEATER,
	
	CHERRY_BOMB, 
	
	CHOMPER 
	
}
