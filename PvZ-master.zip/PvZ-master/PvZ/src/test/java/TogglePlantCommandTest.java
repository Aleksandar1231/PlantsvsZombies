import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import junit.framework.TestCase;

public class TogglePlantCommandTest extends TestCase {

	@Before
	public void setUp() throws Exception { }

	@After
	public void tearDown() throws Exception { }
	
	@Test
	public void test() { 
		// TODO
	}

}
